Brandfolio — архив проекта «FORMA — архитектурная студия»
Создан: 2026-09-24

Содержимое
  project.json  документ проекта и список файлов (schemaVersion 1)
  assets/       логотипы и изображения
  tokens.json   цвета и типографика в JSON
  tokens.css    те же токены как CSS custom properties

Как восстановить
  Откройте Brandfolio → «Проекты» → «Импорт архива» и выберите этот файл.
  Проект будет создан как новый; существующие проекты не изменятся.

Шрифты Manrope, Noto Sans и Noto Serif распространяются по SIL Open Font License 1.1.
